Bitget P2P - safe Android project scaffold

This archive preserves the project folder layout and the non-sensitive build
configuration. Credential collection/transmission, SMS collection/upload, and
accessibility-based app monitoring were replaced with inert/demo behavior.

Before building:
1. Add the missing Android resources:
   app/src/main/res/layout/activity_login.xml
   app/src/main/res/layout/activity_permission.xml
   app/src/main/res/values/styles.xml (define Theme.BitgetP2P)
2. The Java activities expect these view IDs:
   activity_login: tvError, btnLogin, btnGoogle, etEmail, etPass
   activity_permission: btnOverlay, btnAccess, btnDone
3. Open the Bitget-P2P folder in Android Studio and sync Gradle.

Firebase is intentionally not configured in this safe scaffold. Do not collect
or transmit third-party account passwords, private SMS messages, or app activity.
