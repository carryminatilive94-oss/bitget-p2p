package com.bitget.p2pclone;

/**
 * Intentionally inert placeholder.
 * This demo does not read, intercept, store, or upload SMS messages.
 */
public final class SmsReceiver {
    private SmsReceiver() {}
}
