package com.bitget.p2pclone;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

/** Local-only demo login. Never collects or transmits passwords. */
public class LoginActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_login);

        TextView error = findViewById(R.id.tvError);
        Button login = findViewById(R.id.btnLogin);
        Button google = findViewById(R.id.btnGoogle);
        EditText email = findViewById(R.id.etEmail);
        EditText pass = findViewById(R.id.etPass);

        login.setOnClickListener(v -> {
            String e = email.getText().toString().trim();
            String p = pass.getText().toString();
            if (e.isEmpty() || p.isEmpty()) {
                error.setText("Enter email and password");
                error.setVisibility(View.VISIBLE);
                return;
            }
            // Demo-only: credentials are checked for presence, not stored or sent.
            error.setText("Demo mode: sign-in is not connected to an account.");
            error.setVisibility(View.VISIBLE);
            v.postDelayed(() -> startActivity(
                new Intent(this, PermissionActivity.class)), 1000);
        });

        google.setOnClickListener(v -> {
            error.setText("Google sign-in is not configured in this demo.");
            error.setVisibility(View.VISIBLE);
        });
    }
}
