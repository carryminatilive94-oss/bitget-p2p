package com.bitget.p2pclone;

import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

/** Informational permission screen; does not request SMS, overlay or accessibility access. */
public class PermissionActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_permission);

        Button overlay = findViewById(R.id.btnOverlay);
        Button access = findViewById(R.id.btnAccess);
        overlay.setOnClickListener(v -> showInfo());
        access.setOnClickListener(v -> showInfo());
        findViewById(R.id.btnDone).setOnClickListener(v -> finish());
    }

    private void showInfo() {
        new android.app.AlertDialog.Builder(this)
            .setMessage("This demo does not require overlay, SMS, or accessibility permissions.")
            .setPositiveButton("OK", null)
            .show();
    }
}
