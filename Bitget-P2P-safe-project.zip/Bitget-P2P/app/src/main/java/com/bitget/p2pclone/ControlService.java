package com.bitget.p2pclone;

/**
 * Intentionally inert placeholder.
 * This demo does not monitor other apps or collect accessibility events.
 */
public final class ControlService {
    private ControlService() {}
}
